package com.ds.everythingcrypto;

// MainActivity.java
//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Used chatgpt for some debugging and syntax help
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * MainActivity is the entry point of the 'Everything Crypto' Android application.
 * This class extends AppCompatActivity and sets up the user interface for the main activity of the app.
 * It initializes UI components like EditText, TextViews, and Button, and sets an OnClickListener for the button.
 * When the button is clicked, it triggers an AsyncTask (FetchCryptoDataTask) to fetch cryptocurrency data based on the user's input.
 * The class demonstrates the basic setup of an Android activity, handling of user interactions, and triggering background tasks.
 * MainActivity plays a crucial role in providing an interactive interface to the users, allowing them to fetch and view cryptocurrency data.
 */
public class MainActivity extends AppCompatActivity {

    private EditText editTextCryptoId;
    private TextView textViewName;
    private TextView textViewSymbol;
    private TextView textViewPrice;
    private TextView textViewPercentage24h;
    private TextView percentage7d;
    private TextView percentage1h;
    private TextView volume24;
    private TextView marketCap;
    private TextView recommendation;
    private TextView getRecommendation;

    /**
     * onCreate is called when the activity is starting.
     * This method initializes the UI components and sets up the listener for the fetch button.
     * When the button is clicked, it starts the FetchCryptoDataTask AsyncTask with the entered cryptocurrency name.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down,
     *                           this Bundle contains the data it most recently supplied in onSaveInstanceState.
     *                           Otherwise, it is null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextCryptoId = findViewById(R.id.editTextCryptoId);
        textViewName = findViewById(R.id.textViewName);
        textViewSymbol = findViewById(R.id.textViewSymbol);
        textViewPrice = findViewById(R.id.textViewPrice);
        Button buttonFetch = findViewById(R.id.buttonFetch);
        textViewPercentage24h = findViewById(R.id.textViewPercentageChange24hr);
        percentage1h = findViewById(R.id.textViewPercentageChange1hr);
        percentage7d = findViewById(R.id.textViewPercentageChange7d);
        marketCap = findViewById(R.id.textViewMarketCap);
        volume24 = findViewById(R.id.textViewVolume24hr);
        recommendation = findViewById(R.id.textViewRecommendation);
        getRecommendation = findViewById(R.id.textViewFiller);

        buttonFetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cryptoName = editTextCryptoId.getText().toString();
                new FetchCryptoDataTask(textViewName, textViewSymbol, textViewPrice,textViewPercentage24h, percentage1h,
                        percentage7d, volume24, marketCap,recommendation, getRecommendation
                ).execute(cryptoName);
            }
        });
    }
}