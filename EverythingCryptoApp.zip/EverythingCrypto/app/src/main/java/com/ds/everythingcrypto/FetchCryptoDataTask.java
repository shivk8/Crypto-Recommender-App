package com.ds.everythingcrypto;

//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Used chatgpt for some debugging and syntax help
// FetchCryptoDataTask.java
/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * FetchCryptoDataTask is an AsyncTask in an Android application designed to fetch cryptocurrency data from a web service.
 * This class extends AsyncTask to perform network operations on a background thread, updating the UI thread with the results.
 * It makes an HTTP GET request to a specified URL, parses the JSON response, and updates various TextViews in the UI with cryptocurrency data.
 * The class demonstrates the use of Android's AsyncTask for performing background operations and updating the UI with the results.
 * It also showcases handling JSON data, network operations, and efficient UI updates in an Android application.
 * This AsyncTask is crucial for maintaining a responsive user interface while performing time-consuming network operations.
 */

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class FetchCryptoDataTask extends AsyncTask<String, Void, String> {
    private TextView textViewName;
    private TextView textViewSymbol;
    private TextView textViewPrice;

    private TextView textViewPercentage24h;
    private TextView percentage7d;
    private TextView percentage1h;
    private TextView volume24;
    private TextView marketCap;
    private TextView recommendation;
    private TextView getRecommendation;
    /**
     * Constructor for initializing the AsyncTask with references to TextViews that will display the cryptocurrency data.
     *
     * @param textViewName            TextView for displaying the name of the cryptocurrency.
     * @param textViewSymbol          TextView for displaying the symbol of the cryptocurrency.
     * @param textViewPrice           TextView for displaying the price of the cryptocurrency.
     * @param textViewPercentage24h   TextView for displaying the 24-hour percentage change.
     * @param percentage1h            TextView for displaying the 1-hour percentage change.
     * @param percentage7d            TextView for displaying the 7-day percentage change.
     * @param volume24                TextView for displaying the 24-hour trading volume.
     * @param marketCap               TextView for displaying the market capitalization.
     * @param recommendation          TextView for displaying the recommendation.
     * @param getRecommendation       TextView for displaying additional recommendation information.
     */
    public FetchCryptoDataTask(TextView textViewName, TextView textViewSymbol, TextView textViewPrice,
                               TextView textViewPercentage24h,TextView percentage1h,TextView percentage7d,
                               TextView volume24, TextView marketCap, TextView recommendation, TextView getRecommendation) {
        this.textViewName = textViewName;
        this.textViewSymbol = textViewSymbol;
        this.textViewPrice = textViewPrice;
        this.getRecommendation = getRecommendation;
        this.marketCap = marketCap;
        this.percentage1h = percentage1h;
        this.percentage7d = percentage7d;
        this.volume24 = volume24;
        this.textViewPercentage24h = textViewPercentage24h;
        this.recommendation = recommendation;
    }

    /**
     * doInBackground is executed on a background thread and is responsible for performing the network operation.
     * It fetches cryptocurrency data from the specified URL based on the provided cryptocurrency name.
     * This method constructs the API URL, opens a connection, and reads the response.
     * The response from the web service is logged and returned as a string.
     * In case of an exception, it is caught and logged, and null is returned to indicate a failure.
     *
     * @param cryptoName A varargs parameter where the first element is expected to be the name of the cryptocurrency.
     * @return String The response from the web service as a string, or null in case of an error.
     */
    @Override
    protected String doInBackground(String... cryptoName) {
        String apiUrl = "https://verbose-succotash-64rwqwqqprq345v6-8080.app.github.dev/getCryptoData?coinName=" + cryptoName[0];
        try {
            URL url = new URL(apiUrl);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            try {
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                StringBuilder result = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line);
                }
                Log.d("Response from your webservice",result.toString());
                return result.toString();
            } finally {
                urlConnection.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * onPostExecute is executed on the UI thread after the completion of doInBackground.
     * It processes the JSON response string returned by doInBackground.
     * The method parses the JSON to extract various cryptocurrency details like name, symbol, price, percentage changes, market cap, and volume.
     * These details are then used to update the UI components (TextViews) with the respective data.
     * In case of a JSON parsing exception, it is caught and logged.
     * This method ensures that the UI reflects the latest data fetched from the web service.
     *
     * @param result The JSON response string from the web service.
     */
    @Override
    protected void onPostExecute(String result) {
        try {
            JSONObject jsonObject = new JSONObject(result);
            String recommendation = "";
            if(jsonObject != null) {
                recommendation = jsonObject.getString("recommendation");
                jsonObject = jsonObject.getJSONObject("coin_info");
                if(jsonObject != null) {
                    String name = jsonObject.getString("name");
                    String symbol = jsonObject.getString("symbol");
                    String price = jsonObject.getString("price_usd");
                    String percentChange24h = jsonObject.getString("percent_change_24h");
                    String percentChange1h = jsonObject.getString("percent_change_1h");
                    String percentChange7d = jsonObject.getString("percent_change_7d");
                    String marketCap = jsonObject.getString("market_cap_usd");
                    String volume24h = jsonObject.getString("volume24");

                    textViewName.setText("Name: " + name);
                    textViewSymbol.setText("Symbol: " + symbol);
                    textViewPrice.setText("Price: " + price);
                    percentage1h.setText("Percentage Change in 1hr: "+ percentChange1h);
                    textViewPercentage24h.setText("Percentage Chnage in 24 hrs: " +percentChange24h);
                    percentage7d.setText("Percentage Change in 7 days:"  +percentChange7d);
                    getRecommendation.setText(getRecommendation.getText());
                    this.recommendation.setText("Our recommendation to buy: "+recommendation);
                    this.marketCap.setText("Market Cap: "+marketCap);
                    volume24.setText("Volume Traded: "+volume24h);

                    textViewName.setVisibility(View.VISIBLE);
                    textViewSymbol.setVisibility(View.VISIBLE);
                    textViewPrice.setVisibility(View.VISIBLE);
                    percentage1h.setVisibility(View.VISIBLE);
                    textViewPercentage24h.setVisibility(View.VISIBLE);
                    percentage7d.setVisibility(View.VISIBLE);
                    getRecommendation.setVisibility(View.VISIBLE);
                    this.recommendation.setVisibility(View.VISIBLE);
                    this.marketCap.setVisibility(View.VISIBLE);
                    volume24.setVisibility(View.VISIBLE);
                }
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
