package com.ds.cryptowebservice;

import com.mongodb.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import java.io.IOException;

//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Refernces/Sources: https://docs.atlas.mongodb.com/driver-connection/
//Used chatgpt for some debugging and syntax help

/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * The DashboardServlet class is a part of a web application that serves as an interface for displaying cryptocurrency analytics.
 * It initializes a connection to MongoDB, retrieves various cryptocurrency-related data, and forwards this data to a JSP for display.
 * Key features include:
 * - Initialization and destruction of MongoDB client connection.
 * - Handling GET requests by fetching and setting data attributes required for the analytics dashboard.
 * - Redirecting to the appropriate JSP page with the fetched data.
 * This servlet acts as a controller in the MVC pattern, managing the flow of data between the model (MongoDB) and the view (JSP).
 */

@WebServlet(name = "dashboardServlet", value = "/dashboard")
public class DashboardServlet extends HttpServlet {

    private MongoClient mongoClient;
    private MongoDatabase database;


    /**
     * Initializes the servlet, setting up the MongoDB client and establishing a connection to the database.
     * Tests the connection with a simple ping command and handles any MongoDB connection exceptions.
     */
    public void init() {
        String connectionString = "mongodb://admin:admin@ac-vmg9jvj-shard-00-00.kwmn2y1.mongodb.net:27017,ac-vmg9jvj-shard-00-01.kwmn2y1.mongodb.net:27017,ac-vmg9jvj-shard-00-02.kwmn2y1.mongodb.net:27017/crypto?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        mongoClient = MongoClients.create(settings);
        database = mongoClient.getDatabase("crypto");
        try {
            // Send a ping to confirm a successful connection
            database.runCommand(new Document("ping", 1));
            System.out.println("Pinged your deployment. You successfully connected to MongoDB!");
        } catch (MongoException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the GET request by fetching necessary data for the dashboard using the DashboardDataService.
     * Sets the data as request attributes and forwards the request to the JSP page for rendering the dashboard.
     *
     * @param request  HttpServletRequest object that contains the request the client made of the servlet.
     * @param response HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws ServletException if a servlet-specific error occurs.
     * @throws IOException if an I/O error occurs during request processing.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ServletException, IOException {
        // Fetch data for the dashboard
        DashboardDataService dashboardDataService = new DashboardDataService(database);
        request.setAttribute("mostRequestedCryptos", dashboardDataService.getMostRequestedCryptocurrencies());
        request.setAttribute("averageResponseTime", dashboardDataService.getAverageResponseTime());
        request.setAttribute("mostRecommended", dashboardDataService.getMostRecommendedCryptocurrencies());
        request.setAttribute("droppedMost24h", dashboardDataService.getCurrenciesDroppedMost24h());
        request.setAttribute("logData", dashboardDataService.getLogs());

        // Forward to JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("AnalyticsDashboard.jsp");
        dispatcher.forward(request, response);
    }

    /**
     * Destroys the servlet, ensuring the MongoDB client is properly closed.
     * This method is called when the servlet is being taken out of service.
     */
    public void destroy() {
        // Close MongoDB client
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}

