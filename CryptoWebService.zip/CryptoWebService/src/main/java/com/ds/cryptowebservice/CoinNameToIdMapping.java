package com.ds.cryptowebservice;

import java.util.HashMap;
import java.util.Map;
//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Refernces/Sources: https://docs.atlas.mongodb.com/driver-connection/
//Used chatgpt for some debugging and syntax help

/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * CoinNameToIdMapping is a utility class in a cryptocurrency web service designed to map cryptocurrency names to their respective IDs.
 * This mapping is essential for interfacing with external APIs that require cryptocurrency IDs for data retrieval.
 * The class initializes a HashMap in its constructor, pre-loading it with key-value pairs where keys are cryptocurrency names and values are their IDs.
 * It offers a method to retrieve the ID of a cryptocurrency given its name.
 * The usage of HashMap allows for efficient retrieval of IDs, ensuring quick responses for API requests.
 * This class simplifies the process of ID retrieval for various parts of the web service, centralizing the mapping logic in one place.
 */
public class CoinNameToIdMapping {
    private final Map<String, Integer> coinNametoId;
    /**
     * Constructor that initializes the mapping of cryptocurrency names to their respective IDs.
     * The mappings are hardcoded and cover a set of popular cryptocurrencies.
     */
    public CoinNameToIdMapping() {
        // Initialize the mappings in the constructor
        coinNametoId = new HashMap<>();
        coinNametoId.put("Bitcoin", 90);
        coinNametoId.put("Ethereum", 80);
        coinNametoId.put("Doge-Coin", 2);
        coinNametoId.put("Tether", 518);
        coinNametoId.put("Binance-Coin", 2710);
        coinNametoId.put("Solana", 48543);
        coinNametoId.put("Cardano", 257);
        coinNametoId.put("Hedera", 48555);
        coinNametoId.put("Tron", 2713);
        coinNametoId.put("Matic", 33536);
    }

    /**
     * Retrieves the ID of a cryptocurrency based on its name.
     * If the name exists in the mapping, the corresponding ID is returned.
     *
     * @param coinName The name of the cryptocurrency.
     * @return Integer The ID of the cryptocurrency, or null if the name is not found in the mapping.
     */
    public Integer getCoinIdByName(String coinName) {
        // Return coin ID by name
        return coinNametoId.get(coinName);
    }
}
