package com.ds.cryptowebservice;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.*;
import static com.mongodb.client.model.Sorts.descending;
import static java.util.Collections.emptyList;
import org.bson.Document;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Refernces/Sources: https://docs.atlas.mongodb.com/driver-connection/
//Used chatgpt for some debugging and syntax help

/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * The DashboardDataService class is designed to interact with the MongoDB database for a cryptocurrency analytics dashboard.
 * It includes methods for fetching and aggregating data such as the most requested cryptocurrencies, average response time,
 * most recommended cryptocurrencies, cryptocurrencies that have dropped the most in the last 24 hours, and recent logs.
 * These methods utilize MongoDB's aggregation framework to efficiently process and summarize large datasets.
 * This class acts as the data access layer in the application, abstracting the complex queries and providing a clean interface
 * for the servlet to use in preparing data for the dashboard.
 */
public class DashboardDataService {

    private final MongoDatabase database;
    private final MongoCollection<Document> collection;

    public DashboardDataService(MongoDatabase database) {
        this.database = database;
        this.collection = database.getCollection("logger");
    }

    /**
     * Fetches and returns the top 10 most requested cryptocurrencies.
     * Utilizes MongoDB aggregation to group and count requests by cryptocurrency name.
     *
     * @return List<Document> A list of Documents each representing a cryptocurrency and its request count.
     */
    public List<Document> getMostRequestedCryptocurrencies() {
        // Aggregation pipeline to group by "coinName" and count occurrences
        List<Document> mostRequested = collection.aggregate(
                List.of(
                        Aggregates.group("$requestParams.coinName", Accumulators.sum("count", 1)),
                        Aggregates.sort(descending("count")),
                        Aggregates.limit(10)
                )
        ).into(new ArrayList<>());

        return mostRequested;
    }

    /**
     * Calculates and returns the average response time for API requests.
     * Aggregates response time data across all logged requests and computes the average.
     *
     * @return double Average response time in seconds.
     */
    public double getAverageResponseTime() {
        // Aggregation pipeline to calculate the average response time
        List<Document> averageList = collection.aggregate(
                List.of(
                        Aggregates.group(null, Accumulators.avg("averageResponseTime", "$responseTime"))
                )
        ).into(new ArrayList<>());

        if (!averageList.isEmpty()) {
            return averageList.get(0).getDouble("averageResponseTime");
        }
        return 0;
    }

    /**
     * Fetches and returns the top 10 most recommended cryptocurrencies.
     * Filters the logs for recommendations and aggregates them by cryptocurrency name.
     *
     * @return List<Document> A list of Documents each representing a cryptocurrency and its recommendation count.
     */
    public List<Document> getMostRecommendedCryptocurrencies() {
        MongoCollection<Document> collection = database.getCollection("logger");

        // Aggregation pipeline to group by cryptocurrency name within coin_info and count the recommendations
        return collection.aggregate(
                Arrays.asList(
                        Aggregates.match(Filters.eq("apiResponse.recommendation", "Recommended")),
                        Aggregates.group("$apiResponse.coin_info.name", Accumulators.sum("count", 1)),
                        Aggregates.sort(Sorts.descending("count")),
                        Aggregates.limit(10)
                )
        ).into(new ArrayList<>());
    }


    /**
     * Fetches and returns the top 10 cryptocurrencies with the largest drop in value over the last 24 hours.
     * Processes the percentage change data for each cryptocurrency and identifies those with the greatest drop.
     *
     * @return List<Document> A list of Documents each representing a cryptocurrency and its maximum drop in value.
     */
    public List<Document> getCurrenciesDroppedMost24h() {
        List<Document> droppedMost24h = collection.aggregate(Arrays.asList(
                // Convert percent_change_24h to a number since it's stored as a string
                Aggregates.addFields(new Field<>("percentChange24hDouble",
                        new Document("$toDouble", "$apiResponse.coin_info.percent_change_24h"))),
                // Filter out documents without a valid percent change
                Aggregates.match(Filters.exists("percentChange24hDouble")),
                // Group by currency name and find the max drop
                Aggregates.group("$apiResponse.coin_info.name",
                        Accumulators.min("maxDrop", "$percentChange24hDouble")),
                // Sort the results by maxDrop in ascending order (largest negative first)
                Aggregates.sort(Sorts.ascending("maxDrop")),
                // Limit to top results
                Aggregates.limit(10)
        )).into(new ArrayList<>());
        return droppedMost24h;
    }



    /**
     * Retrieves the most recent logs from the database.
     * Limits the results to the last 50 entries for a manageable dataset.
     *
     * @return List<Document> A list of Documents, each representing a log entry.
     */
    public List<Document> getLogs() {
        try {
            List<Document> logs = collection.find()
                    .limit(50)
                    .into(new ArrayList<>());
            System.out.println(logs.toString());
            return logs;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return emptyList();
    }
}