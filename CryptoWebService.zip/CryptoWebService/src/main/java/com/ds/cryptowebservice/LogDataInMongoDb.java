package com.ds.cryptowebservice;

import com.google.gson.JsonObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.http.HttpServletRequest;
import org.bson.Document;
import org.json.JSONObject;
//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Refernces/Sources: https://docs.atlas.mongodb.com/driver-connection/
//Used chatgpt for some debugging and syntax help

/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * This class is responsible for logging request and response data related to cryptocurrency API calls into MongoDB.
 * It captures various metrics such as mobile information, request parameters, API responses, timestamps, and performance indicators.
 * The primary functionality includes:
 * - Logging request data from HttpServletRequest along with API response data.
 * - Extracting specific data from the API response (like 24-hour percentage change, recommendations) and formatting it for MongoDB storage.
 * - Handling the conversion between JSON objects (used for intermediate data handling) and MongoDB Document objects.
 * Each method serves a specific purpose in processing and logging the data, thereby contributing to effective tracking and analysis of cryptocurrency API usage.
 */
public class LogDataInMongoDb {
    MongoDatabase database = null;
    Long timestampResponded = null;

    public LogDataInMongoDb(MongoDatabase database) {
        this.database = database;
    }

    /**
     * Logs request data including API response and various metrics into MongoDB.
     * Captures timestamp of response, calculates response time, and stores detailed information for each request.
     *
     * @param request            HttpServletRequest containing request details.
     * @param apiResponse        String response from the cryptocurrency API.
     * @param timestampReceived  Timestamp when the request was received.
     */
    public void logRequestData(HttpServletRequest request, String apiResponse,Long timestampReceived) {
        timestampResponded = System.currentTimeMillis();
        try {
            MongoCollection<Document> collection = database.getCollection("logger");
            Document log = new Document()
                    .append("mobileInfo", extractMobileInfo(request))
                    .append("requestParams", extractRequestParams(request))
                    .append("apiResponse", Document.parse(apiResponse))
                    .append("timestampReceived", timestampReceived)
                    .append("percent_change_24h", extractPercentage24h(apiResponse))
                    .append("recommendation", extractRecommendation(apiResponse))
                    .append("timestampReceived", timestampReceived)
                    .append("responseTime", (timestampResponded - timestampReceived)/1000.0);
            collection.insertOne(log);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Extracts the 24-hour percentage change from the API response.
     * Parses the response string to JSON, retrieves the percentage change, and formats it for MongoDB.
     *
     * @param response  API response string containing cryptocurrency data.
     * @return Document MongoDB document containing the percentage change.
     */
    private Document extractPercentage24h(String response) {
        JSONObject jsonObject = new JSONObject(response);
        JSONObject coinInfo = jsonObject.getJSONObject("coin_info");
        String percentChange24h = coinInfo.getString("percent_change_24h");
        JsonObject params = new JsonObject();
        params.addProperty("percent_change_24h", percentChange24h);
        // Convert JsonObject to Document
        return Document.parse(params.toString());
    }

    /**
     * Extracts the recommendation from the API response.
     * Parses the response string to JSON and retrieves the recommendation string for logging.
     *
     * @param response  API response string containing cryptocurrency data.
     * @return Document MongoDB document containing the recommendation.
     */
    private Document extractRecommendation(String response) {
        JSONObject jsonObject = new JSONObject(response);
        String recommendation = jsonObject.getString("recommendation");
        JsonObject params = new JsonObject();
        params.addProperty("recommendation", recommendation);
        // Convert JsonObject to Document
        return Document.parse(params.toString());
    }

    /**
     * Extracts request parameters from HttpServletRequest.
     * Specifically retrieves the cryptocurrency name requested by the user.
     *
     * @param request  HttpServletRequest from which parameters are extracted.
     * @return Document MongoDB document containing extracted request parameters.
     */
    private Document extractRequestParams(HttpServletRequest request) {
        JsonObject params = new JsonObject();
        params.addProperty("coinName", request.getParameter("coinName"));
        // Convert JsonObject to Document
        return Document.parse(params.toString());
    }

    /**
     * Extracts mobile device information from HttpServletRequest.
     * Retrieves user agent information from request headers for logging purposes.
     *
     * @param request  HttpServletRequest containing headers with device information.
     * @return Document MongoDB document containing mobile device information.
     */
    private Document extractMobileInfo(HttpServletRequest request) {
        // retrieving device info from headers to create a JsonObject
        JsonObject deviceInfo = new JsonObject();
        deviceInfo.addProperty("User-Agent", request.getHeader("User-Agent"));
        // Convert JsonObject to Document
        return Document.parse(deviceInfo.toString());
    }
}
