package com.ds.cryptowebservice;

import java.io.*;
import com.mongodb.*;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;

//mongodb credentials
//uname: shivaank
//pwd: OUsHsHAv2VJiuchZ

//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Refernces/Sources: https://docs.atlas.mongodb.com/driver-connection/
//Used chatgpt for some debugging and syntax help

/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * CryptoDataServlet is a part of a cryptocurrency web service that interfaces with an external API to fetch data about cryptocurrencies.
 * It initializes necessary components for data fetching and logging, including API handler and MongoDB client.
 * The servlet handles HTTP GET requests, retrieving cryptocurrency data based on user input and logging the request details to MongoDB.
 * It demonstrates the integration of external API data retrieval within a servlet framework and showcases the use of MongoDB for logging and data storage.
 * The servlet follows the typical lifecycle of initialization, handling requests, and destruction, managing resources efficiently throughout its lifecycle.
 */

@WebServlet(name = "cryptoServlet", value = "/getCryptoData")
public class CryptoDataServlet extends HttpServlet {

    FetchDataFromApi fdapi = null;
    CoinNameToIdMapping coinNameToIdMapping = null;
    MongoClient mongoClient = null;
    MongoDatabase database = null;
    Long timestampReceived = null;
    LogDataInMongoDb logDataInMongoDb = null;


    /**
     * Initializes the servlet, setting up necessary components for fetching data from the API and logging into MongoDB.
     * Establishes a connection to the MongoDB database and initializes various helper classes.
     */
    public void init() {
        fdapi = new FetchDataFromApi();
        coinNameToIdMapping = new CoinNameToIdMapping();
        String connectionString = "mongodb://admin:admin@ac-vmg9jvj-shard-00-00.kwmn2y1.mongodb.net:27017,ac-vmg9jvj-shard-00-01.kwmn2y1.mongodb.net:27017,ac-vmg9jvj-shard-00-02.kwmn2y1.mongodb.net:27017/crypto?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        ServerApi serverApi = ServerApi.builder()
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        mongoClient = MongoClients.create(settings);
        database = mongoClient.getDatabase("crypto");
        try {
            // Send a ping to confirm a successful connection
            database.runCommand(new Document("ping", 1));
            System.out.println("Pinged your deployment. You successfully connected to MongoDB!");
        } catch (MongoException e) {
            e.printStackTrace();
        }

        //initialize logDataInMongoDb
        logDataInMongoDb = new LogDataInMongoDb(database);
    }

    /**
     * Handles the GET request by fetching cryptocurrency data based on the provided coin name.
     * Logs the request data, including the response time and the API response, to MongoDB.
     *
     * @param request  HttpServletRequest object that contains the request the client made of the servlet.
     * @param response HttpServletResponse object that contains the response the servlet returns to the client.
     * @throws IOException if an I/O error occurs during request processing.
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Get the coinName from the user
        String name = request.getParameter("coinName");
        timestampReceived = System.currentTimeMillis();
        Integer coinId = coinNameToIdMapping.getCoinIdByName(name);

        // Create and send the response
        String jsonResponse = fdapi.fetchCoinsById(coinId);

        response.setContentType("application/json");
        response.getWriter().write(jsonResponse);

        //store data in mongodb
        logDataInMongoDb.logRequestData(request, jsonResponse,timestampReceived);
    }

    /**
     * Destroys the servlet, ensuring that the MongoDB client is properly closed.
     * This method is called when the servlet is being taken out of service.
     */
    public void destroy() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}