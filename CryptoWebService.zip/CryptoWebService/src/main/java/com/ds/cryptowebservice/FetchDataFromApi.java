package com.ds.cryptowebservice;

import com.google.gson.*;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

//Name: Shivaani Krishnakumar
//andrew id: shivaank
//Refernces/Sources: https://docs.atlas.mongodb.com/driver-connection/
//Used chatgpt for some debugging and syntax help
//fetching coin information from API https://api.coinlore.net/api/ticker

/**
 * Author: Shivaani Krishnakumar (shivaank)
 * Last Modified: November 23, 2023
 *
 * The FetchDataFromApi class is responsible for fetching cryptocurrency information from an external API.
 * It performs HTTP GET requests to the specified API endpoint, processing the JSON response.
 * Key functionalities include:
 * - Fetching coin data by ID and parsing the JSON response.
 * - Creating a structured response including the coin data and a generated recommendation.
 * - Calculating recommendations based on various financial metrics like price changes, market cap, and trading volume.
 * - Exception handling for network issues and JSON parsing errors.
 * This class serves as a bridge between the cryptocurrency API and the application, enabling data retrieval for analysis and display.
 */
public class FetchDataFromApi {
    private static final String BASE_URL = "https://api.coinlore.net/api/ticker/?id=";

    /**
     * Fetches cryptocurrency data by coin ID from the API.
     * Parses the JSON response and handles HTTP response codes.
     * Constructs a response object with coin data and a recommendation.
     *
     * @param coinId  ID of the cryptocurrency to fetch.
     * @return String JSON formatted string with coin data and recommendation.
     * @throws IOException if there is a network error or the URL is incorrect.
     */
    public String fetchCoinsById(Integer coinId) throws IOException {
        JsonObject coinStats = new JsonObject();
        JsonObject response = new JsonObject();
        String recommendation = "";
        if (coinId == null) {
            // Coin name not found in mapping, send an error response
            response.addProperty("error", "No data found for the given coin ID");
            return response.toString();
        }
        URL url = new URL(BASE_URL +  String.valueOf(coinId));
        try {
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                response.addProperty("error", "HTTP error code: " + responseCode);
                return response.toString();
            }

            try (InputStreamReader reader = new InputStreamReader(connection.getInputStream())) {
                JsonArray jsonArray = JsonParser.parseReader(reader).getAsJsonArray();

                if (!jsonArray.isEmpty()) {
                    JsonElement element = jsonArray.get(0); // Get the first element of the array
                    JsonObject fullCoinInfo = element.getAsJsonObject();

                    // Extract only the desired attributes
                    coinStats.addProperty("name", fullCoinInfo.get("name").getAsString());
                    coinStats.addProperty("symbol", fullCoinInfo.get("symbol").getAsString());
                    coinStats.addProperty("price_usd", fullCoinInfo.get("price_usd").getAsString());
                    coinStats.addProperty("percent_change_24h", fullCoinInfo.get("percent_change_24h").getAsString());
                    coinStats.addProperty("percent_change_7d", fullCoinInfo.get("percent_change_7d").getAsString());
                    coinStats.addProperty("percent_change_1h", fullCoinInfo.get("percent_change_1h").getAsString());
                    coinStats.addProperty("market_cap_usd", fullCoinInfo.get("market_cap_usd").getAsString());
                    coinStats.addProperty("volume24", fullCoinInfo.get("volume24").getAsString());
                    recommendation = recommendCrypto(coinStats);
                    return createResponse(coinStats, recommendation);
                } else {
                    response.addProperty("error", "No data found for the given coin ID.");
                }
            } catch (JsonParseException e) {
                response.addProperty("error", "Error parsing the JSON response.");
            }
        } catch (IOException e) {
            response.addProperty("error", "Network error or URL is incorrect.");
        }
        return response.toString();
    }

    /**
     * Creates a JSON response including coin information and a recommendation.
     *
     * @param coinInfo       JsonObject containing coin data.
     * @param recommendation Recommendation based on coin data.
     * @return String JSON formatted response.
     */
    public String createResponse(JsonObject coinInfo, String recommendation) {
        JsonObject response = new JsonObject();
        response.add("coin_info", coinInfo);
        response.addProperty("recommendation", recommendation);
        return response.toString();
    }
    /**
     * Recommends whether to invest in a cryptocurrency based on various financial metrics.
     * Analyzes percentage changes, market cap, and trading volume to score the coin.
     *
     * @param coinInfo JsonObject containing financial data of a cryptocurrency.
     * @return String Recommendation based on the analysis.
     */
    public String recommendCrypto(JsonObject coinInfo) {
        int score = 0;
        try {
            double percentChange24h = getDoubleFromJson(coinInfo, "percent_change_24h");
            double percentChange7d = getDoubleFromJson(coinInfo, "percent_change_7d");
            double percentChange1h = getDoubleFromJson(coinInfo, "percent_change_1h");
            double marketCapUsd = getDoubleFromJson(coinInfo, "market_cap_usd");
            double volume24 = getDoubleFromJson(coinInfo, "volume24");

            // Price Changes
            if (percentChange24h > 5) score++;  // Looking for a significant increase in 24 hours
            if (percentChange7d > 10) score++;  // Looking for a significant increase over a week

            // Stability - Tighter stability criteria
            if (Math.abs(percentChange1h) < 0.5) score++; // Assuming stability if change is less than 0.5%

            // Market Cap - Higher threshold
            if (marketCapUsd > 50_000_000_000L) score++; // Looking for very high market cap

            // Volume - Higher threshold
            if (volume24 > 500_000_000) score++; // Looking for very high trading volume

            // Final Recommendation
            if (score >= 4) {
                return "Highly Recommended";
            } else if (score >= 3) {
                return "Recommended";
            } else {
                return "Not Recommended";
            }
        } catch (NumberFormatException e) {
            return "Data Unavailable";
        }
    }

    /**
     * Extracts a double value from a JSON object given a key.
     * Throws an exception if the key is missing or the value is not a valid double.
     *
     * @param jsonObject JSON object containing the data.
     * @param key        Key for which the double value is required.
     * @return double Value associated with the key.
     * @throws NumberFormatException if the key is missing or value is invalid.
     */
    private double getDoubleFromJson(JsonObject jsonObject, String key) throws NumberFormatException {
        if (jsonObject.has(key) && !jsonObject.get(key).isJsonNull()) {
            return jsonObject.get(key).getAsDouble();
        } else {
            throw new NumberFormatException("Missing or invalid field: " + key);
        }
    }


}

